# javascript-challenge
Silahkan lengkapi kode javascript di repository ini dengan apa yang sudah peserta paham selama proses pembelajaran Sprint 1.
