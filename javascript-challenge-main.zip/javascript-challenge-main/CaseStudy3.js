function nilaiPeserta (nilai) {
    /* 
        Buat proses seleksi kondisi untuk melakukan klasifikasi nilai peserta dengan rincian:
        A = 80 - 100
        B = 60 - 80
        C = 40 - 60
        D = 20 - 40
        E = >20
    */
}

var dataSiswa = [
    ["Jojo", 55.5, nilaiPeserta(nilai)],
    ["Andika", 70.1, nilaiPeserta(nilai)],
    ["Alif", 19, nilaiPeserta(nilai)],
    ["Vista", 102, nilaiPeserta(nilai)]
];

//Silahkan gunakan proses perulangan untuk mengambil semua data array dataSiswa dan tampilkan outputnya.